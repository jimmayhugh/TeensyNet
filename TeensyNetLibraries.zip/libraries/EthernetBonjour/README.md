EthernetBonjour
===============

Bonjour (ZeroConf) Library for Arduino & Teensyduino

mDNS (registering services) works on:
Teensy++2 with WIZ81MJ and
Teensy3 with WIZ820io

DNS-SD (service discovery) is borked

Compatible with Teensyduino 1.18RC2 using the new SPIFIFO Ethernet library routines.
