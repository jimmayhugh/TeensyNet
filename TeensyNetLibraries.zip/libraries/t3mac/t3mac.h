#include <Arduino.h>

extern uint8_t mac[6];

void read_mac();
void print_mac();

