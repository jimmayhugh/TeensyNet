/*************************************************** 
  This is a library for the Adafruit Thermocouple Sensor w/MAX31855K

  Designed specifically to work with the Adafruit Thermocouple Sensor
  ----> https://www.adafruit.com/products/269

  These displays use SPI to communicate, 3 pins are required to  
  interface
  Adafruit invests time and resources providing this open source code, 
  please support Adafruit and open-source hardware by purchasing 
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.  
  BSD license, all text above must be included in any redistribution
 ****************************************************/

#include "MAX31855.h"
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <stdlib.h>


MAX31855::MAX31855(int8_t SCLK, int8_t CS, int8_t MISO) {
  sclk = SCLK;
  cs = CS;
  miso = MISO;

  //define pin modes
  pinMode(cs, OUTPUT);
  pinMode(sclk, OUTPUT); 
  pinMode(miso, INPUT);

  digitalWrite(cs, HIGH);
}

int16_t MAX31855::readCelsius(void) {

  int32_t v;

  v = spiread32();

  if (v & 0x7) {
    // uh oh, a serious problem!
    return NAN; 
  }

  // get rid of internal temp data, and any fault bits
  v >>= 18;

  // pull the bottom 13 bits off
  int16_t temp = v & 0x3FFF;

  // check sign bit
  if (v & 0x2000) 
    temp |= 0xC000;
  
  double centigrade = v;

  // LSB = 0.25 degrees C
  centigrade *= 0.25;
//  Serial.print("centigrade = ");
//  Serial.println(centigrade);
  return centigrade;
}

uint8_t MAX31855::readError() {
  return spiread32() & 0x7;
}


uint32_t MAX31855::spiread32(void) { 
  int i;
  uint32_t d = 0;

  digitalWrite(sclk, LOW);
    delayMicroseconds(150);
  digitalWrite(cs, LOW);
    delayMicroseconds(150);

  for (i=31; i>=0; i--)
  {
    digitalWrite(sclk, LOW);
    delayMicroseconds(150);
    d <<= 1;
    if (digitalRead(miso)) {
      d |= 1;
    }

    digitalWrite(sclk, HIGH);
   delayMicroseconds(150);
  }

  digitalWrite(cs, HIGH);
  return d;
}
