/*  TeensyVersionInfo.h
    Version 0.01 08/31/2014
    by Jim Mayhugh
*/
#ifndef TVI_H
#define TVI_H

#if __MK20DX128__
const char* teensyType = "Teensy3.0 ";
const char* versionStrName   = "TeensyNet 3.0";
#elif __MK20DX256__
const char* teensyType = "Teensy3.1 ";
const char* versionStrName   = "TeensyNet 3.1";
#else
const char* teensyType = "UNKNOWN ";
#endif

const char* versionStrNumber = "V-0.0.45";
const char* versionStrDate   = "10/17/2014";

/* Version History

V-0.0.45 - Added Serial2 debug

*/
#endif
