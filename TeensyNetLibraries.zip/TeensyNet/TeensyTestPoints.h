/*  TeensyTestPoints.h
    Version 0.01 08/31/2014
    by Jim Mayhugh
*/
#ifndef TTP_H
#define TTP_H

// Test Point Stuff
const uint8_t LED1 = 3;
const uint8_t LED2 = 4;
const uint8_t LED3 = 5;
const uint8_t LED4 = 6;
const uint8_t LED5 = 7;
// end of Test Point Stuff

#endif
