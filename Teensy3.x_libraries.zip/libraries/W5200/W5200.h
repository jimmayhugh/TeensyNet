#define W5200 // use this #define in program to allow WIZ812mj (W5100) OR WIZ812io (W5200)

