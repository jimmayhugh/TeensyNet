#include <GSM3MobileDataNetworkProvider.h>

// GSM3MobileDataNetworkProvider* theGSM3MobileDataNetworkProvider;